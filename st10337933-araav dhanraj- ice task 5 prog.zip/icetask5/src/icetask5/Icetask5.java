package icetask5;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Icetask5 extends JFrame {
    private JTextField nameField;
    private JComboBox<String> dayComboBox;
    private JComboBox<String> timeComboBox;
    private JButton submitButton;
    private JList<String> sessionsList;
    private DefaultListModel<String> listModel;

    // Constructor to set up the GUI
    public Icetask5() {
        setTitle("Tutoring Session Scheduler");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        // Text field for student's name
        nameField = new JTextField(20);
        add(new JLabel("Student's Name:"));
        add(nameField);

        // Combo box for session day
        String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
        dayComboBox = new JComboBox<>(days);
        add(new JLabel("Session Day:"));
        add(dayComboBox);

        // Combo box for session time
        String[] times = generateTimes();
        timeComboBox = new JComboBox<>(times);
        add(new JLabel("Session Time:"));
        add(timeComboBox);

        // Submit button
        submitButton = new JButton("Submit");
        add(submitButton);

        // List to display sessions
        listModel = new DefaultListModel<>();
        sessionsList = new JList<>(listModel);
        add(new JScrollPane(sessionsList));

        // Load existing sessions from file
        loadSessions();

        // Add action listener for submit button
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveSession();
            }
        });
    }

    // Generate session times in 1-hour intervals
    private String[] generateTimes() {
        String[] times = new String[6];
        for (int i = 0; i < 6; i++) {
            times[i] = String.format("%02d:00 PM", 3 + i);
        }
        return times;
    }

    // Load sessions from file
    private void loadSessions() {
        try (BufferedReader reader = new BufferedReader(new FileReader("tutoring_sessions.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                listModel.addElement(line);
            }
        } catch (IOException e) {
            System.out.println("Error loading sessions: " + e.getMessage());
        }
    }

    // Save session details to file
    private void saveSession() {
        String name = nameField.getText();
        String day = (String) dayComboBox.getSelectedItem();
        String time = (String) timeComboBox.getSelectedItem();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the student's name.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sessionDetails = name + " - " + day + " at " + time;
        listModel.addElement(sessionDetails);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("tutoring_sessions.txt", true))) {
            writer.write(sessionDetails);
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving session: " + e.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
        }

        nameField.setText(""); // Clear input field after submission
    }

    // Main method to run the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Icetask5 app = new Icetask5();
            app.setVisible(true);
        });
    }
}

